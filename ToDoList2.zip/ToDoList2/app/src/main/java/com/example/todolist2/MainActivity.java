package com.example.todolist2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //References the Home Screen
        Intent MainViewIntent = new Intent(this, MainView.class);
        this.startActivity(MainViewIntent);
    }
}
